let students = [
        {
  firstname: 'Irina',
  lastname: 'Nosevich',
  age: 19,
  averagerating: 5.7
        },
        {
firstname: 'Denis',
lastname: 'Nosevich',
age: 16,
averagerating: 8.4
        },
{
firstname: 'Zhenya',
lastname: 'Nosevich',
age: 18,
averagerating: 4.9
},

];

const Student = (function() {
  
  
        const fill = (students) => {
        let table = document.createElement('table');
        let tr = document.createElement('tr');
        table.appendChild(tr);
        tr.appendChild(document.createElement('th'));
        tr.appendChild(document.createElement('th'));
        tr.appendChild(document.createElement('th'));
        tr.appendChild(document.createElement('th'));
        table.rows[0].cells[0].innerHTML = 'Firstname';
        table.rows[0].cells[1].innerHTML = 'Lastname';
        table.rows[0].cells[2].innerHTML = 'Age';
        table.rows[0].cells[3].innerHTML = 'Averagerating';

        //css таблицы
table.setAttribute('border', '1');
table.setAttribute('color', '000');
table.setAttribute('width','500');
table.setAttribute('height', '500');
        
        document.body.appendChild(table);
        let i = 1;
        
        students.forEach(element => {
        let tr = document.createElement('tr');
        table.appendChild(tr);
        tr.appendChild(document.createElement('td'));
        tr.appendChild(document.createElement('td'));
        tr.appendChild(document.createElement('td'));
        tr.appendChild(document.createElement('td'));
        table.rows[i].cells[0].textContent = element.firstname;
        table.rows[i].cells[1].innerHTML = element.lastname;
        table.rows[i].cells[2].innerHTML = element.age;
        table.rows[i].cells[3].innerHTML = element.averagerating;
        i++;
        });
        
        sumFun();
        
        };
        
        function refreshData() {
        let table = document.querySelector('table');
        let i = 1;
        students.forEach(element => {
        let tr = document.createElement('tr');
        table.appendChild(tr);

        tr.appendChild(document.createElement('td'));
        tr.appendChild(document.createElement('td'));
        tr.appendChild(document.createElement('td'));
        tr.appendChild(document.createElement('td'));
        table.rows[i].cells[0].textContent = element.firstname;
        table.rows[i].cells[1].innerHTML = element.lastname;
        table.rows[i].cells[2].innerHTML = element.age;
        table.rows[i].cells[3].innerHTML = element.averagerating;
        i++;
        });
        
        sumFun();
        }
        
        
        function sumFun() {
        const el = document.querySelector('table');
        const resultEl = document.querySelector('#result');
        let sum = 0;
        Array.from(el.children).forEach((child, index) => {
        if (index !== 0) {
        sum += +child.lastElementChild.textContent;
        }
        });
        
        resultEl.textContent = +(sum / students.length).toFixed(2);
        }
        
        
        
        
        return {
        fill,
        refreshData
        }
        })();
        Student.fill(students);




        ////функции к 3 лабе
        
        function plusFun()
        {
        students.push({ firstname: document.getElementById('firstname').value,
        lastname: document.getElementById('lastname').value,
        age: document.getElementById('age').value,
        averagerating: document.getElementById('averagerating').value
        }, );
        Student.refreshData(students);
        }
        
        function delFun() {
        let a=document.getElementById('del').value;
        let table = document.querySelector('table');
        let b=a-1;
        table.children[a].remove();
        students.splice(b, 1);
        Student.refreshData(students);
        }
      




























