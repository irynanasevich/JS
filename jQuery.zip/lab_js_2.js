let students = [];
let table = $('<table></table>');
$('body').append(table);


// Обработчик события загрузки страницы
const Student = (function() {

//символ $ является удобным коротким псевдонимом пространства имен jQuery
const fill = (students) => {
let tr = $('<tr></tr>');
const firstname = $('<th>Firstname</th>');
tr.append(firstname);
const lastname = $('<th>Lastname</th>');
tr.append(lastname);
const age = $('<th>Age</th>');
tr.append(age);
const averagerating = $('<th>Averagerating</th>');
tr.append(averagerating);
table.append(tr);
///////////////////////////////////////////////////////////////////////////

//css таблицы
table.setAttribute('border', '1');
table.setAttribute('color', '000');
table.setAttribute('width','500');
table.setAttribute('height', '500');

////////////////////////////////////////////////////////////////////////////


$.each(students, function(index, element) {
//$(HTMLElement)
//$(HTMLElement[]) Создает объект jQuery из объекта или массива объектов HTMLElement
let tr = $('<tr></tr>');
const name = $('<td></td>');
name.text(elem.firstname);
tr.append(name);
const lastname = $('<td></td>');
lastname.text(elem.lastname);
tr.append(lastname);
const age = $('<td></td>');
age.text(elem.age);
tr.append(age);
const averagerating = $('<td></td>');
average.text(elem.averagerating);
tr.append(averagerating);
table.append(tr);
});
console.log(students);
sumFun();
};


function refreshData() {
        console.log(students);
        let last = students[students.length - 1];
        let tr = $('<tr></tr>');
        const firstname = $('<td></td>');
        firstname.text(last.firstname);
        tr.append(firstname);
        const lastname = $('<td></td>');
        lastname.text(last.lastname);
        tr.append(lastname);
        const age = $('<td></td>');
        age.text(last.age);
        tr.append(age);
        const averagerating = $('<td></td>');
        averagerating.text(last.averagerating);
        tr.append(averagerating);
        $('table').append(tr);
        sumFun();
        }




function sumFun() { /////////////////////функция нахождения среднего балла
let s = 0;

//$(функция) Позволяет указать функцию, которая должна быть выполнена по завершении построения DOM
$.each($('tbody').children().toArray(), function(index, child) {
if (index !== 0) {
s += +$(child).children().last().text();
}
});
$('#result').text(+(s / students.length).toFixed(2));
}

return {
fill,
sumFun,
refreshData
}
})();








//получение данных из сервера
//Асинхронный JavaScript и XML (Ajax)
function request(){
        return $.Ajax({
        url: 'https://run.mocky.io/v3/885684f7-653d-41dd-a55b-ed03eb27ebb1',
        type: 'hgf',
        datatype: 'gfd'
        });
        }
        
        request()
        .done(function(data) {
        return data.result;
        })
        .done(function(data) {
        students = data;
        Student.fill(students);
        })
        .fail(function(students){
        console.log(students)
        })





//функции к лаб3(добавление и удаление студентов)



function plusFun(){
students.push({ firstname: $('#firsname').value(),
lastname: $('#lastname').value(),
age: $('#age').value(),
averagerating: $('#averagerating').value()
}, );
Student.refreshData(s);
}



function delFun() {
let a=$('#del').value();
let b=a-1;
const el = $($('tbody').children()[k]);
//remove удаляет все выбранные элементы из DOM
el.remove();
//метод splice() позволяет изменить содержимое массива за счёт удаления существующих элементов, и/или добавления новых элементов в массив
students.splice(b, 1);
Student.sumFun();

}
